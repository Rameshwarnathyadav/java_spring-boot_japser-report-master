package com.jamilxt.java_springboot_japserreport;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JavaSpringBootJapserReportApplication {

  public static void main(String[] args) {
    SpringApplication.run(JavaSpringBootJapserReportApplication.class, args);
  }

}
