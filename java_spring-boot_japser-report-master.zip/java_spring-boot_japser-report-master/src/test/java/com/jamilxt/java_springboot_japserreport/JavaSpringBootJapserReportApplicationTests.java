package com.jamilxt.java_springboot_japserreport;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JavaSpringBootJapserReportApplicationTests {

  @Test
  void contextLoads() {
  }

}
